@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 > nul
title GwazorDPI
set "ROOT=%~dp0"
cd /d "%ROOT%"

:: ---- права администратора ----
if /i not "%~1"=="admin" (
    if not exist "%ROOT%bin\gDPI.exe" (
        echo   %CR%✗ Папка bin не найдена. Распакуйте архив целиком.%C0%
        pause
        exit /b 1
    )
    echo   %CW%↑ Запрашиваю права администратора...%C0%
    powershell -NoProfile -Command "Start-Process 'cmd.exe' -ArgumentList '/c \"\"%~f0\" admin\"' -Verb RunAs"
    exit /b
)
cd /d "%ROOT%"

set "SVC=gDPI Service"
set "BIN_PATH=%ROOT%bin\"
set "GameFilterTCP=843,4530-4533,9090-9093,19090-19091,27015-27200"
set "GameFilterUDP=3478-3479,4379-4380,5055-5062,6250,12000-27200"

:: ---- цвета ----
set "ESC="
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C0=" & set "CW=" & set "CL=" & set "CD=" & set "CG=" & set "CR=" & set "CY="
if defined ESC (
    set "C0=%ESC%[0m"
    set "CW=%ESC%[97m"
    set "CL=%ESC%[37m"
    set "CD=%ESC%[90m"
    set "CG=%ESC%[92m"
    set "CR=%ESC%[91m"
    set "CY=%ESC%[93m"
)

if not exist "%ROOT%lists\ipset-exclude-user.txt" echo 203.0.113.113/32>"%ROOT%lists\ipset-exclude-user.txt"
if not exist "%ROOT%lists\list-general-user.txt" (
    echo # Never leave this file empty>"%ROOT%lists\list-general-user.txt"
    echo domain.example.abc>>"%ROOT%lists\list-general-user.txt"
)
if not exist "%ROOT%lists\list-exclude-user.txt" echo domain.example.abc>"%ROOT%lists\list-exclude-user.txt"
if not exist "%ROOT%profiles" mkdir "%ROOT%profiles"

:: ===================================================================
:menu
call :header
call :state
echo   %CD%┌─%C0% %CW%СТАТУС СИСТЕМЫ%C0% %CD%────────────────────────────────────┐%C0%
echo   %CD%│%C0%  %CL%Провайдер .......%C0% !S_PROV!
echo   %CD%│%C0%  %CL%Стратегия .......%C0% !S_STR!
echo   %CD%│%C0%  %CL%Автозапуск ......%C0% !S_SVC!
echo   %CD%│%C0%  %CL%Обход запущен ...%C0% !S_RUN!
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
echo   %CD%┌─%C0% %CW%УПРАВЛЕНИЕ%C0% %CD%────────────────────────────────────────┐%C0%
echo   %CD%│%C0%                                                     %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%1%C0%%CD%]%C0%  %CL%Подобрать и настроить под провайдера%C0%         %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%2%C0%%CD%]%C0%  %CL%Включить автозапуск%C0% %CD%(gDPI Service)%C0%           %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%3%C0%%CD%]%C0%  %CL%Выключить автозапуск и остановить обход%C0%      %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%4%C0%%CD%]%C0%  %CL%Добавить свой сайт в список%C0%                  %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%5%C0%%CD%]%C0%  %CL%Диагностика системы%C0%                          %CD%│%C0%
echo   %CD%│%C0%                                                     %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CD%0%C0%%CD%]%C0%  %CD%Выход%C0%                                        %CD%│%C0%
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
set "ch="
set /p "ch=   %CL%Ваш выбор:%C0% "
if "!ch!"=="1" goto setup
if "!ch!"=="2" goto install
if "!ch!"=="3" goto remove
if "!ch!"=="4" goto addsite
if "!ch!"=="5" goto diag
if "!ch!"=="0" exit /b
goto menu

:: ===================================================================
:header
cls
echo.
echo                        %CW%GwazorDPI%C0%
echo.
exit /b

:state
set "S_PROV=%CR%не выбран%C0%"
set "S_STR=%CR%не выбрана%C0%"
set "S_SVC=%CR%выключен%C0%"
set "S_RUN=%CR%нет%C0%"
if exist "%ROOT%profiles\provider.txt" (
    set /p S_PROV=<"%ROOT%profiles\provider.txt"
    set "S_PROV=%CG%!S_PROV!%C0%"
)
if exist "%ROOT%core\active_name.txt" (
    set /p S_STR=<"%ROOT%core\active_name.txt"
    set "S_STR=%CG%!S_STR!%C0%"
)
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "gDPI Service" >nul 2>&1
if not errorlevel 1 set "S_SVC=%CG%включен%C0%"
schtasks /Query /TN "gDPI Service" >nul 2>&1
if not errorlevel 1 set "S_SVC=%CG%включен%C0%"
tasklist /FI "IMAGENAME eq gDPI.exe" 2>nul | find /i "gDPI.exe" >nul
if not errorlevel 1 set "S_RUN=%CG%да%C0%"
tasklist /FI "IMAGENAME eq gDPI Service.exe" 2>nul | find /i "gDPI Service.exe" >nul
if not errorlevel 1 set "S_RUN=%CG%да%C0%"
exit /b

:: ===================================================================
::  1. ПРОВАЙДЕР
:: ===================================================================
:setup
call :header
echo   %CD%┌─%C0% %CW%ВЫБОР ПРОВАЙДЕРА%C0% %CD%──────────────────────────────────┐%C0%
echo   %CD%│%C0%                                                     %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%1%C0%%CD%]%C0%  %CL%Ростелеком%C0%                                   %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%2%C0%%CD%]%C0%  %CL%МТС%C0%                                          %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%3%C0%%CD%]%C0%  %CL%Билайн%C0%                                       %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%4%C0%%CD%]%C0%  %CL%МегаФон%C0%                                      %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%5%C0%%CD%]%C0%  %CL%Дом.ру%C0%                                       %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%6%C0%%CD%]%C0%  %CL%ТТК%C0%                                          %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%7%C0%%CD%]%C0%  %CL%Другой или не знаю%C0%                           %CD%│%C0%
echo   %CD%│%C0%                                                     %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%8%C0%%CD%]%C0%  %CL%Выбрать стратегию вручную%C0%                    %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CD%0%C0%%CD%]%C0%  %CD%Назад%C0%                                        %CD%│%C0%
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
set "pv="
set /p "pv=   %CL%Номер:%C0% "
if "!pv!"=="0" goto menu
if "!pv!"=="8" goto manual
set "PKEY="
set "PNAME="
if "!pv!"=="1" set "PKEY=rostelecom" & set "PNAME=Ростелеком"
if "!pv!"=="2" set "PKEY=mts" & set "PNAME=МТС"
if "!pv!"=="3" set "PKEY=beeline" & set "PNAME=Билайн"
if "!pv!"=="4" set "PKEY=megafon" & set "PNAME=МегаФон"
if "!pv!"=="5" set "PKEY=domru" & set "PNAME=Дом.ру"
if "!pv!"=="6" set "PKEY=ttk" & set "PNAME=ТТК"
if "!pv!"=="7" set "PKEY=other" & set "PNAME=Другой"
if not defined PKEY goto setup
>"%ROOT%profiles\provider.txt" echo !PNAME!

set "SAVED="
if exist "%ROOT%profiles\!PKEY!.txt" set /p SAVED=<"%ROOT%profiles\!PKEY!.txt"
if not defined SAVED goto detect_mode
if not exist "%ROOT%strategies\!SAVED!" goto detect_mode
echo.
echo   %CL%Для провайдера%C0% %CW%!PNAME!%C0% %CL%найдена стратегия:%C0%
echo   %CG%✓ !SAVED!%C0%
echo.
echo     %CD%[%C0%%CW%1%C0%%CD%]%C0%  %CL%Применить её%C0%
echo     %CD%[%C0%%CW%2%C0%%CD%]%C0%  %CL%Подобрать заново%C0%
echo     %CD%[%C0%%CD%0%C0%%CD%]%C0%  %CD%Назад%C0%
echo.
set "sv="
set /p "sv=   %CL%Выбор:%C0% "
if "!sv!"=="0" goto menu
if "!sv!"=="1" (
    call :apply "!SAVED!"
    goto applied
)

:detect_mode
echo.
echo   %CD%┌─%C0% %CW%РЕЖИМ ПОДБОРА%C0% %CD%─────────────────────────────────────┐%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%1%C0%%CD%]%C0%  %CL%Быстрый%C0% %CD%— 8 первых стратегий (~3-5 мин)%C0%      %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CW%2%C0%%CD%]%C0%  %CL%Полный%C0%  %CD%— все 22 стратегии (до 15 мин)%C0%       %CD%│%C0%
echo   %CD%│%C0%   %CD%[%C0%%CD%0%C0%%CD%]%C0%  %CD%Назад%C0%                                        %CD%│%C0%
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
set "dm="
set /p "dm=   %CL%Выбор:%C0% "
if "!dm!"=="0" goto menu
set "LIMIT=8"
if "!dm!"=="2" set "LIMIT=22"
if not "!dm!"=="1" if not "!dm!"=="2" goto detect_mode

where curl.exe >nul 2>&1
if errorlevel 1 (
    echo   %CR%Не найден curl.exe ^(нужна Windows 10 версии 1803 или новее^).%C0%
    pause
    goto menu
)

taskkill /IM "gDPI Service.exe" /F >nul 2>&1
taskkill /IM gDPI.exe /F >nul 2>&1

echo.
echo   %CD%• Проверяю доступность сайтов без обхода...%C0%
call :probe
set "BASE=!SC!"
if !BASE! GEQ !TOTAL! (
    echo   %CG%✓ Все тестовые сайты открываются без обхода.%C0%
    echo   %CD%Если в браузере что-то не открывается, смените DNS на 1.1.1.1 или 8.8.8.8.%C0%
    pause
    goto menu
)
echo   %CL%Открывается без обхода:%C0% %CW%!BASE!%C0% %CD%из%C0% %CW%!TOTAL!%C0%
echo.

set "PREV="
if exist "%ROOT%core\active_name.txt" set /p PREV=<"%ROOT%core\active_name.txt"
set "BEST=-1"
set "BESTFILE="
set "DONE=0"
set "N=0"
for /f "delims=" %%f in ('dir /b /on "%ROOT%strategies\*.txt"') do (
    set /a N+=1
    if !N! LEQ !LIMIT! if not "!DONE!"=="1" call :try "%%f"
)
taskkill /IM gDPI.exe /F >nul 2>&1
del "%ROOT%test_dpi.bat" >nul 2>&1

echo.
if !BEST! LEQ !BASE! (
    echo   %CR%✗ Ни одна стратегия не улучшила результат.%C0%
    if defined PREV call :apply "!PREV!"
    echo   %CD%Попробуйте полный режим, смените DNS на 1.1.1.1 или отключите VPN.%C0%
    pause
    goto menu
)
echo   %CG%✓ Лучший результат: !BESTFILE! — !BEST! из !TOTAL!%C0%
>"%ROOT%profiles\!PKEY!.txt" echo !BESTFILE!
call :apply "!BESTFILE!"
goto applied

:applied
echo.
echo   %CG%✓ Стратегия настроена и сохранена для gDPI Service.exe.%C0%
echo   %CD%─────────────────────────────────────────────────────%C0%
echo   %CD%Запустите gDPI Service.exe для старта обхода.%C0%
echo   %CD%Хотите автозапуск с Windows? Включите пункт 2 в меню.%C0%
echo   %CD%─────────────────────────────────────────────────────%C0%
pause
goto menu

:: пробуем одну стратегию напрямую через склейку head.txt + active.txt
:try
set "TF=%~1"
call :apply "%~1"
taskkill /IM gDPI.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul
copy /b /y "%ROOT%core\head.txt" + "%ROOT%core\active.txt" "%ROOT%test_dpi.bat" >nul
call "%ROOT%test_dpi.bat"
del "%ROOT%test_dpi.bat" >nul 2>&1
cd /d "%ROOT%"
timeout /t 4 /nobreak >nul
tasklist /FI "IMAGENAME eq gDPI.exe" 2>nul | find /i "gDPI.exe" >nul
if errorlevel 1 (
    echo   %CD%[%CW%!N!%CD%]%C0% %CL%%~n1%C0% %CD%—%C0% %CR%✗ не запустился%C0%
    exit /b
)
call :probe
if !SC! GTR !BEST! (
    set "BEST=!SC!"
    set "BESTFILE=%~1"
)
if !SC! GEQ !TOTAL! (
    echo   %CD%[%CW%!N!%CD%]%C0% %CW%%~n1%C0% %CD%—%C0% %CG%✓ !SC! из !TOTAL!%C0%
    set "DONE=1"
) else (
    echo   %CD%[%CW%!N!%CD%]%C0% %CL%%~n1%C0% %CD%—%C0% %CL%!SC! из !TOTAL!%C0%
)
exit /b

:probe
set "SC=0"
set "TOTAL=0"
for /f "usebackq eol=# tokens=*" %%u in ("%ROOT%core\targets.txt") do (
    set /a TOTAL+=1
    set "code=000"
    for /f %%c in ('curl.exe -s -o NUL -m 5 --connect-timeout 4 -w "%%{http_code}" "%%u" 2^>nul') do set "code=%%c"
    if not "!code!"=="000" set /a SC+=1
)
exit /b

:apply
copy /y "%ROOT%strategies\%~1" "%ROOT%core\active.txt" >nul
>"%ROOT%core\active_name.txt" echo %~1
exit /b

:manual
call :header
echo   %CD%┌─%C0% %CW%СПИСОК СТРАТЕГИЙ%C0% %CD%──────────────────────────────────┐%C0%
echo.
set "MN=0"
for /f "delims=" %%f in ('dir /b /on "%ROOT%strategies\*.txt"') do (
    set /a MN+=1
    set "MF!MN!=%%f"
    echo     %CD%[%C0%%CW%!MN!%C0%%CD%]%C0%  %CL%%%~nf%C0%
)
echo.
echo     %CD%[%C0%%CD%0%C0%%CD%]%C0%  %CD%Назад%C0%
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
set "mc="
set /p "mc=   %CL%Номер:%C0% "
if "!mc!"=="0" goto menu
if "!mc!"=="" goto manual
set "SEL="
set "SEL=!MF%mc%!"
if not defined SEL goto manual
call :apply "!SEL!"
echo.
echo   %CG%✓ Выбрана стратегия: !SEL!%C0%
echo.
pause
goto menu

:: ===================================================================
::  2. ВКЛЮЧИТЬ АВТОЗАПУСК (без немедленного запуска)
:: ===================================================================
:install
call :header
if not exist "%ROOT%gDPI Service.exe" (
    echo   %CR%✗ Не найден файл gDPI Service.exe.%C0%
    pause
    goto menu
)
net stop "gDPI" >nul 2>&1
sc delete "gDPI" >nul 2>&1
net stop "gDPI Service" >nul 2>&1
sc delete "gDPI Service" >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "gDPI Service" /t REG_SZ /d "\"%ROOT%gDPI Service.exe\"" /f >nul 2>&1
schtasks /Create /TN "gDPI Service" /TR "\"%ROOT%gDPI Service.exe\"" /SC ONLOGON /RL HIGHEST /F >nul 2>&1
echo   %CG%✓ Автозапуск gDPI Service включен.%C0%
echo   %CD%Программа будет автоматически запускаться при входе в Windows.%C0%
echo.
pause
goto menu

:: ===================================================================
::  3. ВЫКЛЮЧИТЬ АВТОЗАПУСК И ОСТАНОВИТЬ
:: ===================================================================
:remove
call :header
net stop "gDPI" >nul 2>&1
sc delete "gDPI" >nul 2>&1
net stop "gDPI Service" >nul 2>&1
sc delete "gDPI Service" >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "gDPI Service" /f >nul 2>&1
schtasks /Delete /TN "gDPI Service" /F >nul 2>&1
taskkill /IM "gDPI Service.exe" /F >nul 2>&1
taskkill /IM gDPI.exe /F >nul 2>&1
net stop "GDivert" >nul 2>&1
sc delete "GDivert" >nul 2>&1
net stop "GDivert14" >nul 2>&1
sc delete "GDivert14" >nul 2>&1
net stop "WinDivert" >nul 2>&1
sc delete "WinDivert" >nul 2>&1
echo   %CG%✓ Автозапуск gDPI Service выключен.%C0%
echo   %CL%• Обход остановлен.%C0%
echo.
pause
goto menu

:: ===================================================================
::  4. СВОЙ САЙТ
:: ===================================================================
:addsite
call :header
echo   %CD%┌─%C0% %CW%ДОБАВИТЬ СВОЙ САЙТ%C0% %CD%────────────────────────────────┐%C0%
echo   %CD%│%C0%  %CL%Введите домен без http и слэшей (пр: example.com)%C0%  %CD%│%C0%
echo   %CD%│%C0%  %CD%Пустая строка — возврат в меню.%C0%                    %CD%│%C0%
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
echo.
set "dom="
set /p "dom=   %CL%Домен:%C0% "
if "!dom!"=="" goto menu
echo !dom!| findstr /r /i "^[a-z0-9][a-z0-9.-]*\.[a-z][a-z0-9-]*$" >nul
if errorlevel 1 (
    echo   %CR%✗ Это не похоже на домен.%C0% %CD%Пример: example.com%C0%
    pause
    goto addsite
)
>>"%ROOT%lists\list-general-user.txt" echo !dom!
echo.
echo   %CG%✓ Добавлено: !dom!%C0%
echo   %CD%• Перезапустите gDPI Service.exe, чтобы список применился.%C0%
echo.
pause
goto menu

:: ===================================================================
::  5. ДИАГНОСТИКА
:: ===================================================================
:diag
call :header
echo   %CD%┌─%C0% %CW%ДИАГНОСТИКА СИСТЕМЫ%C0% %CD%───────────────────────────────┐%C0%
echo.
set "PROBLEMS=0"

if exist "%ROOT%gDPI Service.exe" (echo     %CG%✓ OK%C0%    %CL%gDPI Service.exe на месте%C0%) else (echo     %CR%✗ FAIL%C0%  %CR%нет gDPI Service.exe%C0% & set /a PROBLEMS+=1)
if exist "%ROOT%bin\gDPI.exe" (echo     %CG%✓ OK%C0%    %CL%bin\gDPI.exe на месте%C0%) else (echo     %CR%✗ FAIL%C0%  %CR%нет bin\gDPI.exe%C0% & set /a PROBLEMS+=1)
if exist "%ROOT%bin\WinDivert64.sys" (echo     %CG%✓ OK%C0%    %CL%WinDivert64.sys на месте%C0%) else (echo     %CR%✗ FAIL%C0%  %CR%нет bin\WinDivert64.sys — проверьте антивирус%C0% & set /a PROBLEMS+=1)
if exist "%ROOT%bin\WinDivert.dll" (echo     %CG%✓ OK%C0%    %CL%WinDivert.dll на месте%C0%) else (echo     %CR%✗ FAIL%C0%  %CR%нет bin\WinDivert.dll%C0% & set /a PROBLEMS+=1)

sc query BFE 2>nul | find "RUNNING" >nul
if errorlevel 1 (echo     %CR%✗ FAIL%C0%  %CR%служба Base Filtering Engine не запущена%C0% & set /a PROBLEMS+=1) else (echo     %CG%✓ OK%C0%    %CL%Base Filtering Engine работает%C0%)

where curl.exe >nul 2>&1
if errorlevel 1 (echo     %CR%✗ FAIL%C0%  %CR%нет curl.exe — автоподбор недоступен%C0% & set /a PROBLEMS+=1) else (echo     %CG%✓ OK%C0%    %CL%curl.exe найден%C0%)

echo "%ROOT%" | find /i "OneDrive" >nul
if not errorlevel 1 (echo     %CR%✗ FAIL%C0%  %CR%папка в OneDrive — перенесите в C:\gDPI%C0% & set /a PROBLEMS+=1)

echo "%ROOT%" | findstr /r "[^ -~]" >nul
if not errorlevel 1 (echo     %CR%✗ FAIL%C0%  %CR%кириллица в пути — перенесите в C:\gDPI%C0% & set /a PROBLEMS+=1)

set "CONFL="
for %%s in (GoodbyeDPI zapret discordfix_zapret winws1 winws2) do (
    sc query "%%s" >nul 2>&1
    if not errorlevel 1 set "CONFL=!CONFL! %%s"
)
if defined CONFL (
    echo     %CR%✗ FAIL%C0%  %CR%конфликтующие службы:!CONFL!%C0%
    set /a PROBLEMS+=1
    echo.
    set "yn="
    set /p "yn=   %CL%Удалить их? [y/N]:%C0% "
    if /i "!yn!"=="y" (
        for %%s in (!CONFL!) do (
            net stop "%%s" >nul 2>&1
            sc delete "%%s" >nul 2>&1
            echo           %CG%✓ удалено: %%s%C0%
        )
    )
) else (
    echo     %CG%✓ OK%C0%    %CL%конфликтующих служб нет%C0%
)

echo.
echo   %CD%└─────────────────────────────────────────────────────┘%C0%
if "!PROBLEMS!"=="0" (echo   %CG%✓ Проблем не найдено.%C0%) else (echo   %CR%✗ Найдено проблем: !PROBLEMS!%C0%)
echo   %CD%Если сайты не открываются: смените DNS на 1.1.1.1 или 8.8.8.8 и отключите VPN.%C0%
echo.
pause
goto menu